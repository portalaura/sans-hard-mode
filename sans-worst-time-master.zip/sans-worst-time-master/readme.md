# Worst Time Simulator
This project is a clone of [Bad Time Simulator](https://jcw87.github.io/c2-sans-fight).
It was made with [Construct 2](https://www.scirra.com/construct2).